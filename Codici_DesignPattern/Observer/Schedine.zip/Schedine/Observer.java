public interface Observer {
    public void update(double val);
}